(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.ring = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// base
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(204,204,204,0)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAkchBQh2AcAAAmQAAAnB2AbQB3AcClgBQCoABB1gcQB3gbgBgnQABgmh3gcQh1gbioAAQilAAh3Abg");
	this.shape.setTransform(82,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(204,204,204,0.008)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAkchBQh3AcAAAmQAAAnB3AbQB2AcCmgBQCoABB1gcQB4gbAAgnQAAgmh4gcQh1gbioAAQimAAh2Abg");
	this.shape_1.setTransform(82,19);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(204,204,204,0.02)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAkehBQh3AcAAAmQAAAnB3AbQB4AcCmAAQCpAAB2gcQB4gbAAgnQAAgmh4gcQh2gbipAAQimAAh4Abg");
	this.shape_2.setTransform(82,19);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(204,204,204,0.039)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAkghCQh4AdAAAmQAAAnB4AcQB4AcCoAAQCqAAB3gcQB4gcAAgnQAAgmh4gdQh3gbiqAAQioAAh4Abg");
	this.shape_3.setTransform(82,19);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(204,204,204,0.067)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAkjhCQh5AcAAAnQAAAnB5AcQB5AdCqAAQCsAAB4gdQB6gcAAgnQAAgnh6gcQh4gcisAAQiqAAh5Acg");
	this.shape_4.setTransform(82,19);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(204,204,204,0.098)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAkmhDQh7AdAAAnQAAAoB7AcQB6AdCsAAQCtAAB6gdQB8gcgBgoQABgnh8gdQh6gcitAAQisAAh6Acg");
	this.shape_5.setTransform(82,19);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(204,204,204,0.141)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAkrhEQh8AeAAAnQAAAoB8AdQB8AeCvAAQCwAAB8geQB9gdAAgoQAAgnh9geQh8gdiwABQivgBh8Adg");
	this.shape_6.setTransform(82,19);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(204,204,204,0.188)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAkwhFQh/AdABApQgBApB/AeQB+AdCyAAQCzAAB/gdQB+geAAgpQAAgph+gdQh/gdizAAQiyAAh+Adg");
	this.shape_7.setTransform(82,19);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(204,204,204,0.247)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAk3hGQiBAeABApQgBAqCBAeQCCAeC1AAQC3AACAgeQCCgeAAgqQAAgpiCgeQiAgei3AAQi1AAiCAeg");
	this.shape_8.setTransform(82,19);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(204,204,204,0.314)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAk+hJQiEAgABAqQgBArCEAfQCFAeC5AAQC7AACDgeQCFgfAAgrQAAgqiFggQiDgei7AAQi5AAiFAeg");
	this.shape_9.setTransform(82,19);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(204,204,204,0.392)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAlGhLQiHAhAAArQAAAsCHAfQCIAgC+AAQDAAACHggQCHgfABgsQgBgriHghQiHgejAAAQi+AAiIAeg");
	this.shape_10.setTransform(82,19);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(204,204,204,0.475)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAlPhNQiKAhAAAtQAAAuCKAfQCMAhDDAAQDFAACLghQCMgfgBguQABgtiMghQiLgfjFAAQjDAAiMAfg");
	this.shape_11.setTransform(82,19);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(204,204,204,0.569)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAlZhOQiOAhgBAuQABAvCOAhQCQAiDJgBQDLABCPgiQCPghAAgvQAAguiPghQiPgijLAAQjJAAiQAig");
	this.shape_12.setTransform(82,19);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(204,204,204,0.671)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAljhRQiTAjAAAvQAAAwCTAjQCTAiDQAAQDSAACSgiQCVgjAAgwQAAgviVgjQiSgijSAAQjQAAiTAig");
	this.shape_13.setTransform(82,19);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(204,204,204,0.776)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAluhUQiYAlAAAwQAAAyCYAjQCYAjDWAAQDYAACYgjQCYgjAAgyQAAgwiYglQiYgjjYAAQjWAAiYAjg");
	this.shape_14.setTransform(82,19);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(204,204,204,0.886)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAl7hWQicAkAAAzQAAA0CcAjQCeAmDdAAQDfAACdgmQCdgjAAg0QAAgzidgkQidgljfABQjdgBieAlg");
	this.shape_15.setTransform(82,19);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CCCCCC").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAmHhZQiiAmAAA0QAAA1CiAmQCjAmDkAAQDmAACigmQCjgmgBg1QABg0ijgmQiigmjmAAQjkAAijAmg");
	this.shape_16.setTransform(82,19);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(204,204,204,0.745)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAmmhhQiwApAAA5QAAA5CwApQCvApD3AAQD5AACvgpQCwgpAAg5QAAg5iwgpQivgoj5AAQj3AAivAog");
	this.shape_17.setTransform(82,19);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(204,204,204,0.518)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAnEhoQi7AtAAA8QAAA9C7ArQC8AtEIgBQEKABC7gtQC8grABg9QgBg8i8gtQi7grkKAAQkIAAi8Arg");
	this.shape_18.setTransform(82,19);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(204,204,204,0.329)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAnbhuQjGAwABA/QgBBADGAuQDFAuEXAAQEXAADFguQDGguAAhAQAAg/jGgwQjFgtkXAAQkXAAjFAtg");
	this.shape_19.setTransform(82,19);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(204,204,204,0.188)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAnthxQjNAwAABCQAABDDNAvQDNAwEhAAQEhAADNgwQDNgvAAhDQAAhCjNgwQjNgvkhAAQkhAAjNAvg");
	this.shape_20.setTransform(82,19);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(204,204,204,0.086)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAn6h0QjSAxAABEQAABFDSAwQDSAxEpAAQEpAADSgxQDSgwAAhFQAAhEjSgxQjSgxkpAAQkpAAjSAxg");
	this.shape_21.setTransform(82,19);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(204,204,204,0.027)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAoCh2QjUAyAABFQAABFDUAyQDWAyEtgBQEuABDUgyQDWgyAAhFQAAhFjWgyQjUgxkuAAQktAAjWAxg");
	this.shape_22.setTransform(82,19);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(204,204,204,0)").s().p("ApDCGQjwg3AAhPQAAhODwg3QDwg4FTAAQFTAADwA4QDxA3AABOQAABPjxA3QjwA4lTAAQlTAAjwg4gAoFh3QjWAygBBGQABBGDWAxQDXAzEvAAQEvAADWgzQDYgxAAhGQAAhGjYgyQjWgxkvAAQkvAAjXAxg");
	this.shape_23.setTransform(82,19);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,164,38);


(lib.pupil = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// hl
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhIBJQgegfAAgqQAAgqAegeQAegeAqAAQAqAAAfAeQAeAeAAAqQAAAqgeAfQgfAegqAAQgqAAgegeg");
	this.shape.setTransform(35.85,16.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AioCpQhGhGAAhjQAAhiBGhGQBGhGBiAAQBjAABGBGQBGBGAABiQAABjhGBGQhGBGhjAAQhiAAhGhGg");
	this.shape_1.setTransform(23.9,23.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,47.8,47.8);


(lib.lid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#592C82").s().p("AmgGgIAAtBQGgh0GhB0IAANBQjGA8jRAAQjQAAjag8g");
	this.shape.setTransform(41.725,41.8328);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-5.7,83.5,95.10000000000001);


(lib.ringmove = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ring("synched",0);
	this.instance.setTransform(82.05,-10.95,0.6579,0.6579,0,0,0,82,19.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:19,scaleX:1,scaleY:1,x:82,y:111.5,startPosition:23},23,cjs.Ease.quadOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-23.5,164,154);


(lib.eye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Aj6D7QhohoAAiTQAAiSBohoQBohoCSAAQCTAABoBoQBoBoAACSQAACThoBoQhoBoiTAAQiSAAhohog");
	mask.setTransform(35.5,35.5);

	// lid_t
	this.instance = new lib.lid("synched",0);
	this.instance.setTransform(34.75,-49.2,1,1,0,0,0,41.7,41.7);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(17).to({startPosition:0},0).to({y:23.3},4,cjs.Ease.quadIn).to({startPosition:0},1,cjs.Ease.quadOut).to({y:-49.2},4,cjs.Ease.quadOut).wait(22));

	// lid_b
	this.instance_1 = new lib.lid("synched",0);
	this.instance_1.setTransform(34.75,109.25,1,1,0,0,0,41.7,41.7);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(48));

	// pupil
	this.instance_2 = new lib.pupil("synched",0);
	this.instance_2.setTransform(35.55,35.55,1,1,0,0,0,23.9,23.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(48));

	// white
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Aj6D7QhohoAAiTQAAiSBohoQBohoCSAAQCTAABoBoQBoBoAACSQAACThoBoQhoBoiTAAQiSAAhohog");
	this.shape.setTransform(35.5,35.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,71,71);


(lib.base = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mouth
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("ABpi4IB9AAACbiLQhbEiklAi");
	this.shape.setTransform(107.025,127.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(48));

	// eye
	this.instance = new lib.eye("synched",0);
	this.instance.setTransform(67.5,70.55,1,1,0,0,0,35.5,35.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(48));

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ap7J8QkIkHAAl1QAAl0EIkHQEHkIF0AAQF1AAEHEIQEIEHAAF0QAAF1kIEHQkHEIl1AAQl0AAkHkIg");
	mask.setTransform(90,90);

	// hl
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#592C82").s().p("Ap7J8QkIkHAAl1QAAl0EIkHQEHkIF0AAQF1AAEHEIQEIEHAAF0QAAF1kIEHQkHEIl1AAQl0AAkHkIg");
	this.shape_1.setTransform(72,81);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(48));

	// base
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3F2B56").s().p("Ap7J8QkIkHAAl1QAAl0EIkHQEHkIF0AAQF1AAEHEIQEIEHAAF0QAAF1kIEHQkHEIl1AAQl0AAkHkIg");
	this.shape_2.setTransform(90,90);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,180,180);


(lib.rings = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ring
	this.instance = new lib.ringmove("synched",0);
	this.instance.setTransform(82,19,1,1,0,0,0,82,19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(24));

	// ring_copy
	this.instance_1 = new lib.ringmove("synched",5);
	this.instance_1.setTransform(82,19,1,1,0,0,0,82,19);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(24));

	// ring_copy_copy
	this.instance_2 = new lib.ringmove("synched",11);
	this.instance_2.setTransform(82,19,1,1,0,0,0,82,19);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(24));

	// ring_copy_copy_copy
	this.instance_3 = new lib.ringmove("synched",15);
	this.instance_3.setTransform(82,19,1,1,0,0,0,82,19);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(24));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-23.5,164,154);


(lib.basemove = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.base("synched",0);
	this.instance.setTransform(90,90,1,1,0,0,0,90,90);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:130,startPosition:23},23,cjs.Ease.quadInOut).to({y:90,startPosition:47},24,cjs.Ease.quadInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,180,220);


// stage content:
(lib.botcharacter = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// base
	this.instance = new lib.basemove("synched",0);
	this.instance.setTransform(122,98.75,0.5,0.5,0,0,0,81,84.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(48));

	// rings
	this.instance_1 = new lib.rings("synched",0);
	this.instance_1.setTransform(128,161,0.5,0.5,0,0,0,82,19);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(48));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(206.5,181.5,-35,35.30000000000001);
// library properties:
lib.properties = {
	id: '56DB47B116167A478E0D63E2AE89440B',
	width: 250,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 0.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['56DB47B116167A478E0D63E2AE89440B'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;